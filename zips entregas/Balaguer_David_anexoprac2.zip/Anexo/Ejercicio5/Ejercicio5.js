'use strict'
alert("Bienvenida");
setTimeout(()=>{
    window.open("./Ejercicio5.js")
},2000);