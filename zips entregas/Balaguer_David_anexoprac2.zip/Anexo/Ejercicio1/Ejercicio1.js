'use strict'
function avisar() {
    alert("Estas sobre un hipervinculo");
}