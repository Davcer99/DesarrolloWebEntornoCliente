'use strict'
function cambiarTamaño (elemento){
    elemento.style = "font-size: 16pt"
}
function cambiarTamañoPequeño (elemento){
    elemento.style = "font-size: 12pt"
}