'use strict'
document.write("<h1>Bienvenido a mi página</h1>");
document.write("Nombre del navegador: " + navigator.appName);
if (confirm("Quieres continuar?")){
    alert("Continuamos");
};