'use strict'
function cambiarFondo(color) {
    document.bgColor=color;
};
