<?php
$json = $_POST["json"];
echo($json);
?>
