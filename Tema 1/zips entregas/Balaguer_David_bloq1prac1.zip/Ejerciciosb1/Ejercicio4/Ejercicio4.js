'use strict'
var numero = parseInt(prompt("introduce un numero"));
if ((numero % 2) == 0){
    alert("El numero intoducido es par")
}else{
    alert("El numero introducido es impar")
}