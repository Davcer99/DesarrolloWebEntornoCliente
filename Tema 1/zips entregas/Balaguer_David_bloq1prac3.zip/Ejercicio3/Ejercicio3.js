'use strict'
function cambiarFondo(color) {
    document.getElementById('bienvenida').style.backgroundColor = color;
}