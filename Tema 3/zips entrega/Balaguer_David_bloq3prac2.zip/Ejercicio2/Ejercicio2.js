$(document).ready(function(){
    $("#btn").click(function(){
        $("#contenedor").load("formulario.html")
    }) 
});