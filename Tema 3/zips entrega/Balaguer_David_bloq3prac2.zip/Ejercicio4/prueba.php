<?php
    $nombre = $_POST["nombre"];
    echo "Hola $nombre";
?>