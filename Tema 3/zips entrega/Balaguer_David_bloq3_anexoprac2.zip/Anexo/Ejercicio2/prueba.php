<?php
sleep(2);
$time = time();
echo date("d-m-Y (H:i:s)", $time);
?>