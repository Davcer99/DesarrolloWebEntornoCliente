 

$(document).ready(function(){
  $( function() {
    $( "#accordion" ).accordion();
  } );
});